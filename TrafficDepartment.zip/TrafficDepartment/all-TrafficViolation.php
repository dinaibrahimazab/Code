<?php
session_start();
require_once 'dashboard/include/connection.php';
if (isset($_SESSION["car_id"]) && isset($_SESSION["car_number"]) ) {
   $id=$_SESSION["car_id"];
   $car_number=$_SESSION["car_number"];
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>جميع المخالفات</title>
    <link rel="stylesheet" href="./css/all-TrafficViolation.css">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous" />
</head>

<body>
    <header class="header">
        <div class="logo">ادارة المرور العامة</div>
        <div id="icone" class="fas fa-bars"></div>
        <nav class="navbar">
            <a href="homePage.php">الصفحة الرئيسية</a>
            <a href="logout.php">تسجيل الخروج</a>
        </nav>
    </header>
    <section class="coursess allCourses" id="courses">
    <?Php
                 if (isset($_GET['page'])) {
                    $page = $_GET['page'];
                  } else {
                    $page = 1;
                  }
                  $limit = 6;
                  $start = ($page - 1) * $limit;
                $query="SELECT * FROM trafficviolations WHERE carID = '$id'";
                $res=mysqli_query($con,$query);

                if (mysqli_num_rows($res)>0) {
                    while ($row=mysqli_fetch_assoc($res)) {
                    ?>
    
        <div class="card-courses">
            <div class="card">
                <label for="">قيمة الغرامة:</label>
                <h3><?php echo $row['a_fine']?> جنيهاً</h3>
                <label for="">سبب الغرامة:</label>
                <h3><?php echo $row['reason']?></h3>
                <a href="payment.php">ادفع الان</a>
                <a href="grievances.php">ارسال شكوي</a>
            </div>
        </div>
    
    <?php
                }
                }else {
                    ?>
                     

                     <div class="alert alert-warning text-center" role="alert">
                       <h4>لاتوجد اي فيديوهات</h4>
                    </div>

                     <?php
                }?>
                </section>
    
    <script src="./JS/main.js"></script>
</body>

</html>